package decorateurMagasin;

public interface AbstractionIHM {
    public void afficherMenu();
}
