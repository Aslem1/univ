package decorateurMagasin;

public class ImplementationIHM implements AbstractionIHM{

    @Override
    public void afficherMenu() {
        System.out.println("0 - Quitter");
    }
    
}
