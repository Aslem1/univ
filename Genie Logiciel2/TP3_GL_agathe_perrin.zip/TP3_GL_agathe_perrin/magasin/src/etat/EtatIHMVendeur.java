
package etat;

public class EtatIHMVendeur {
    
}
