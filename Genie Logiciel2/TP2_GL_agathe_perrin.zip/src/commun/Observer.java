package commun;

public interface Observer {
    public void update();
}
