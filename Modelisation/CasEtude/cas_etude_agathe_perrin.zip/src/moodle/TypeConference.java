package moodle;

public enum TypeConference {
	AUDIO,
	VIDEO;
}
