package moodle;

public enum Status {
	DEPOSE,
	NON_DEPOSE,
	RETARD,
	ANNULE;
}
