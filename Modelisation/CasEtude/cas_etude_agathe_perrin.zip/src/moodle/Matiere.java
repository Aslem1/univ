package moodle;

public enum Matiere {
	INFORMATIQUE,
	STATISTIQUES,
	MODELISATION,
	POOA;
}
