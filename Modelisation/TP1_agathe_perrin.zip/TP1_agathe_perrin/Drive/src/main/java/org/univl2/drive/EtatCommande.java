package org.univl2.drive;

public enum EtatCommande {
	EN_COURS,
	VALIDE,
	EN_PREPARATION,
	PRETE,
	TERMINEE,
	ANNULEE
}
