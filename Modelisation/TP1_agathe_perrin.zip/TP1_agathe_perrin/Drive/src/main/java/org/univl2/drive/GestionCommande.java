package org.univl2.drive;

public class GestionCommande {
	private GestionCommande() {
		
	}
	
	// Affecter preparateur
	public static void affecterPreparateur (Commande commande, Personnel preparateur, String date, String heure) {
		
	}
	
	// Ajouter produit
	public static boolean ajouterProduit (Commande commande, Produit produit, int quantite) {
		return true;
	}
	
	// Annuler commande
	public static void annulerCommande (Commande commande) {
		
	}
	
	// Choix creneau
	public static void choixCreneau (Commande commande, String heure, String date) {
		
	}
	
	// Creer commande
	public static Commande creerCommande(Client client) {
		return null;
	}
	
	// Notifier preparateur
	public static void notifierPreparateur (Commande commande) {
		
	}
	
	// Recuperer commande
	public static void recupererCommande (Commande commande) {
		
	}
	
	public static void validerCommande (Commande commande) {
		
	}
}
