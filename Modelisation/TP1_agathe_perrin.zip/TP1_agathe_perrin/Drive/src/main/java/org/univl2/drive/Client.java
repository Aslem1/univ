package org.univl2.drive;

import java.util.List;

public class Client extends Personne {
    private String dateInscription;
    private List<Commande> commandes;

    // Constructeur
    public Client(String nom, String prenom) {
        super(nom, prenom);
    }
        
    // ajouterCommande
    public void ajouterCommande (Commande commande) {
    	
    }

    
}
