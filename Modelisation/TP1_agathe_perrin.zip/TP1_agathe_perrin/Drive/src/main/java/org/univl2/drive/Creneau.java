package org.univl2.drive;

public class Creneau {
    private String jour;
    private String heureDebut;
    private String heureFin;

    // Constructeur
    public Creneau(String jour, String heureDebut, String heureFin) {
        this.jour = jour;
        this.heureDebut = heureDebut;
        this.heureFin = heureFin;
    }
    
}
