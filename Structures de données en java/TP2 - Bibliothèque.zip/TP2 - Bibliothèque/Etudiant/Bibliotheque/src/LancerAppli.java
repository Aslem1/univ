

class LancerAppli {

    public static void main(String args[]) {
           Fenetre maFenetre = new Fenetre("Bibliotheque", 1000, 500); // Creation de la fenetre graphique

    }
}