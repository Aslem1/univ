import java.util.ArrayList;

public class QStore
{
public static final int N=2100;   // Nombre d'elements dans la liste au depart
//---------------------------------------------------------------------------
private ArrayList <Integer> T ;
//---------------------------------------------------------------------------
public int compteurDicho; // voir la dichotomie O(lg N )
//---------------------------------------------------------------------------

QStore( ) {
	this.compteurDicho=0; 
	this.T = new ArrayList();  	
}
//---------------------------------------------------------------------------

public void exec() {
    
}


// recherche Dichotomique dans le tableau -----------
public boolean dicho( int n , int iDebut, int iFin ) {
    
    return true;
}

// methode EstTrie ----------------------------------
public boolean estTrie() {
return false;
}




}