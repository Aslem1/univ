import java.awt.*;



public class testLsystem {

   public static void main( String [] args ) {
      LSystem l = new LSystem();
      l.derivation();
      
      
      l.interpretation();
          
   
   }

}

