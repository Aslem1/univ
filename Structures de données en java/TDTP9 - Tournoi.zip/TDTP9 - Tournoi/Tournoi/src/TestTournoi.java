class TestTournoi {
	
 
 public static void main(String args[]) {
 	Fenetre maFenetre = new Fenetre("Tournoi tennis", 1200, 600); // Creation de la fenetre graphique
 	
 }
 
}