#ifndef PROJETEXEC_CONVERSION_H
#define PROJETEXEC_CONVERSION_H

const char* convert_date(char *num);

#endif //PROJETEXEC_CONVERSION_H
