#ifndef PROJET_LIBRARY_H
#define PROJET_LIBRARY_H

int main();

#endif //PROJET_LIBRARY_H
