//
// Created by Martin Ehlinger on 10/12/2020.
//

#ifndef AFFICHAGE_AFFICHAGE_H
#define AFFICHAGE_AFFICHAGE_H

void found(char string[16], char string1[9]);

#endif //AFFICHAGE_AFFICHAGE_H
