//
// Created by Martin Ehlinger on 18/12/2020.
//

#ifndef SPELLNUMBERFRROMAN_LIBRARY_FR_ROMAN_H
#define SPELLNUMBERFRROMAN_LIBRARY_FR_ROMAN_H

char *int_to_roman(int n);

#endif //SPELLNUMBERFRROMAN_LIBRARY_FR_ROMAN_H
