//
// Created by Martin Ehlinger on 10/12/2020.
//

#ifndef SPELLNUMBER_LIBRARY_FR_DATE_H
#define SPELLNUMBER_LIBRARY_FR_DATE_H

static char *hundred(long number);

static char *conv_letter_number(long number);

#endif //SPELLNUMBER_LIBRARY_FR_DATE_H
