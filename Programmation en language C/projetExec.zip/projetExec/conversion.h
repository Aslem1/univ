
#ifndef PROJETEXEC_CONVERSION_H
#define PROJETEXEC_CONVERSION_H

char* convertDate();

#endif //PROJETEXEC_CONVERSION_H
