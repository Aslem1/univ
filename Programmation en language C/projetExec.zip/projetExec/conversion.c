#include "conversion.h"
#include <stdio.h>
#include <stdlib.h>

char* convertDate(int day, int month, int year) {
    char *months[] = {
            "Janvier", "Février", "Mars", "Avril",
            "Mai", "Juin", "Juillet", "Août",
            "Septembre", "Octobre", "Novembre", "Decembre",
    };

    printf("%d %s %d ", day, months[month - 1], year);
    char result[50];
    //sprintf(result, "%d %s %d ", day, months[month - 1], year);

    return result;
}
