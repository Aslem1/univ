#include <stdio.h>
#include "conversion.h"

int main() {
    int day, month, year;
    printf("Entrez une date(DD/MM/YYYY): ");
    scanf("%d/%d/%d", &day, &month, &year);
    printf (convertDate(day, month, year));
    return 0;
}
