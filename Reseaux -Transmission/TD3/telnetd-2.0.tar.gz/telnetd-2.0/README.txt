Java TelnetD library (embeddable telnet daemon)
Copyright (c) 2000-2005 Dieter Wimberger 
All rights reserved.

This library is released under the terms of the BSD style license 
you received along with your working copy (see LICENSE.txt).

For documentation, please see:
http://telnetd.sourceforge.net

This project is free and open source and this will not change in the future.
However, working on the project requires resources (beyond the ones provided
by SF). If you are willing to support the project financially, you are welcome
to make donations (via SF/PayPal).
Donated money will be used to pay Internet provider bills, provide and maintain 
network facilities, enhance computing power and memory capacity. 5% will automatically
be transfered to SF.net, for providing the hosting facilities on SF. 

