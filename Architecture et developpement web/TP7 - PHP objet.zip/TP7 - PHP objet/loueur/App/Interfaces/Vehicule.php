<?php
interface Vehicule {
    public function rouler();
    public function naviguer();
    public function voler();
}
?>