<footer>
	<p>	<a id="goto-admin" href="admin.php">Admin</a></p>
	<p id="extra">
		Site Web Avancés - Année 2016 - version HTML 5
	</p>
</footer>