package org.aslem.transportmarchandises;

public class Test {
    public static void main (String[] args) {
        Conteneur conteneur1 = new Conteneur(0, 0);
        String test = "tabarnak " + conteneur1;
        System.out.println(test);
    }
}
