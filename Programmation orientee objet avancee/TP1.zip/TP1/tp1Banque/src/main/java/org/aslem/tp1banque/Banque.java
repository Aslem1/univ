package org.aslem.tp1banque;

public class Banque {
    private String nomBanque;

    // Constructeur de banque
    public Banque(String nomBanque) {
        this.nomBanque = nomBanque;
    }
    
    
}
